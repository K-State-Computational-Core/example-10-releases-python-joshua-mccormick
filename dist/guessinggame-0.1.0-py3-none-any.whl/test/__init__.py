"""Test Package for GuessingGame.

Author: Joshua McCormick
Verison: 0.1.0
"""
